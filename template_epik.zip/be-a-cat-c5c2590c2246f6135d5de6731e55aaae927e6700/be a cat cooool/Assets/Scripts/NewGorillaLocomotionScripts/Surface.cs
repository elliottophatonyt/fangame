﻿namespace GorillaLocomotion
{
    using UnityEngine;

    public class Surface : MonoBehaviour
    {
        public float slipPercentage;
    }
}